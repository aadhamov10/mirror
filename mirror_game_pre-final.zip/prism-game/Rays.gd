
extends Node2D

var rays_count = GlobalVariables.rays_count
var rays = []
var direction = GlobalVariables.light_target_position

var max_bounces = 100

var ray_length = 4000.0

var ray_segments = []


func _ready():
	for i in range(rays_count):
		var ray = RayCast2D.new()
		add_child(ray)

		ray.enabled = true
		ray.position = GlobalVariables.Light_source_position

		if direction == Vector2(2000, 0) or direction == Vector2(-2000, 0):
			ray.position.y = ray.position.y - rays_count / 2 + i + 1
		else:
			ray.position.x = ray.position.x - rays_count / 2 + i + 1

		ray.target_position = direction

		rays.append(ray)


func _physics_process(_delta):
	var space_state = get_world_2d().direct_space_state

	ray_segments.clear()
	
	for target in get_tree().get_nodes_in_group("Targets"):
			target.hit = false
			target.before_hit()
			
	for ray in rays:

		var segments = []

		# Initial position and direction
		var current_start = ray.global_position
		var current_direction = (
			ray.to_global(ray.target_position) - current_start
		).normalized()
		
		
		# Repeat the collision and reflection process
		for bounce_index in range(max_bounces):
			var query = PhysicsRayQueryParameters2D.create(
				current_start,
				current_start + current_direction * ray_length
			)

			query.collision_mask = ray.collision_mask
			query.collide_with_bodies = ray.collide_with_bodies
			query.collide_with_areas = ray.collide_with_areas

			var hit = space_state.intersect_ray(query)

			# Nothing was hit: draw the remaining ray and stop
			if hit.is_empty():
				var final_end = current_start + current_direction * ray_length
				segments.append([current_start, final_end])
				break

			# Something was hit
			var collision_point = hit["position"]
			var normal = hit["normal"]
			var collider = hit["collider"]
			
			GlobalVariables.targets_hit = []
			GlobalVariables.targets_hit.resize(GlobalVariables.target_number)
			GlobalVariables.targets_hit.fill(false)
			

			segments.append([current_start, collision_point])
			
			if collider.is_in_group("Targets"):
				collider.is_hit()
				break
			# Calculate reflection
			current_direction = current_direction.bounce(normal).normalized()

			# Start slightly beyond the collision to avoid hitting
			# the exact same surface repeatedly
			current_start = collision_point + current_direction * 1.0

		ray_segments.append(segments)

	queue_redraw()


func _draw():
	for segments in ray_segments:

		for i in range(segments.size()):

			var start = to_local(segments[i][0])
			var end = to_local(segments[i][1])

			if i == 0:
				draw_line(start, end, Color.YELLOW, 1.0)
			else:
				draw_line(start, end, Color.GREEN, 1.0)
