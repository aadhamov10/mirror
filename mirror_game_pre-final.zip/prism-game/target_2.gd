extends StaticBody2D

var hit = false
# Called when the node enters the scene tree for the first time.
func _ready():
	position = GlobalVariables.target_position[1]
	$Polygon2D.color = Color(255, 255, 255)

func before_hit():
	$Polygon2D.color = Color(255, 255, 255)

func is_hit():
	GlobalVariables.targets_hit[1] = true
	$Polygon2D.color = Color.CORAL
	hit = true

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass
