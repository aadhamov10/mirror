extends Node

var Light_source_position = Vector2(randi_range(4, 60)*10, randi_range(4, 60)*10)
var light_power = 100
var game_started = false
var player_name = "Player"
var rays_count = 40 #must be divisible by 2
var light_target_position = [Vector2(2000, 0), Vector2(0, 2000)].pick_random()
var target_position = [Vector2(randi_range(60, 1800), randi_range(60, 1000)), Vector2(randi_range(60, 1800), randi_range(60, 1000))]
var targets_hit = [false, false]
var target_number = 2
