extends RayCast2D

@onready var beam: Line2D = $"../Line2D light visual"

# Called when the node enters the scene tree for the first time.
func _ready():
	target_position = GlobalVariables.light_target_position
	position = GlobalVariables.Light_source_position

func _process(_delta):
	force_raycast_update()

	var start = position
	var end = target_position

	if is_colliding():
		end = to_local(get_collision_point())

	beam.clear_points()
	beam.add_point(start)
	beam.add_point(end)
