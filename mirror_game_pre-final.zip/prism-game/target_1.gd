extends StaticBody2D

# Called when the node enters the scene tree for the first time.

var hit = false

func _ready():
	position = GlobalVariables.target_position[0]
	$Polygon2D.color = Color(255, 255, 255)

func before_hit():
	$Polygon2D.color = Color(255, 255, 255)

func is_hit():
	GlobalVariables.targets_hit[0] = true
	$Polygon2D.color = Color.CORAL
	hit = true

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass
