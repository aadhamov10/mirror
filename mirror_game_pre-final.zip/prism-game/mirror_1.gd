
extends StaticBody2D

var dragging = false
var rotating = false

var drag_offset = Vector2.ZERO

# Rotation starting information
var starting_mouse_angle = 0.0
var starting_mirror_rotation = 0.0


func _input_event(_viewport, event, _shape_idx):

	if event is InputEventMouseButton:

		if event.button_index == MOUSE_BUTTON_LEFT:
			dragging = event.pressed

			if dragging:
				drag_offset = global_position - get_global_mouse_position()

		if event.button_index == MOUSE_BUTTON_RIGHT:
			rotating = event.pressed

			if rotating:
				# Save the mouse's starting angle
				var mouse_position = get_global_mouse_position()
				var direction = mouse_position - global_position

				starting_mouse_angle = direction.angle()

				# Save the mirror's current rotation
				starting_mirror_rotation = global_rotation


func _input(event):

	if event is InputEventMouseButton:

		if event.button_index == MOUSE_BUTTON_LEFT:
			if not event.pressed:
				dragging = false

		if event.button_index == MOUSE_BUTTON_RIGHT:
			if not event.pressed:
				rotating = false


func _process(_delta):

	if dragging:
		global_position = get_global_mouse_position() + drag_offset

	if rotating:
		var mouse_position = get_global_mouse_position()
		var direction = mouse_position - global_position

		var current_mouse_angle = direction.angle()

		# Calculate how much the mouse has rotated
		var angle_difference = wrapf(
			current_mouse_angle - starting_mouse_angle,
			-PI,
			PI
		)

		# Apply that rotation to the mirror
		global_rotation = starting_mirror_rotation + angle_difference
