extends Polygon2D


# Called when the node enters the scene tree for the first time.
func _draw():
	var aaa = GlobalVariables.Light_source_position
	var size = (GlobalVariables.rays_count)/2
	draw_circle(aaa, size, Color.WHITE)
